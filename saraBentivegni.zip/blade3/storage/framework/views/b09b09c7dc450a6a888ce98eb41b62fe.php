<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Elenco libri</title>
    <?php echo $__env->make('bootstrap', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body>
    <div class="container">


        <a href="/books/create">Inserisci nuovo libro</a>

        <table class="table">
            <thead>
                <tr>
                    <th>Titolo</th>
                    <th>Autore</th>
                    <th>Riassunto</th>
                    <th>Numero pagine</th>
                    <th>Valutazione</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                    <tr>
                        <td><?php echo e($book->title); ?></td>
                        <td><?php echo e($book->author); ?></td>
                        <td><?php echo e($book->abstract); ?></td>
                        <td><?php echo e($book->pages); ?></td>
                        <td><?php echo e($book->rating); ?></td>
                        <td>
                        <?php if($book->updated_at): ?>
                        <?php echo e($book->updated_at->format('d/m/Y H:i:s')); ?>

                        <?php endif; ?>
                    </td>
                        <td>
                            <a href="/books/edit/<?php echo e($book->id); ?>">Modifica</a>
                            <a href="/books/delete/<?php echo e($book->id); ?>">Elimina</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html><?php /**PATH C:\Users\Utente Corso IFTS\Desktop\laravel\blade3\resources\views/books/index.blade.php ENDPATH**/ ?>