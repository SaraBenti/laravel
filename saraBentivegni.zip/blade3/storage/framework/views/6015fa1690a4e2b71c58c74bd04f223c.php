<div class="text-center text-muted w-full">
    By SaraBenti - <?php echo e(date ('d/m/Y')); ?>

</div><?php /**PATH C:\Users\Utente Corso IFTS\Desktop\laravel\blade3\resources\views/footer.blade.php ENDPATH**/ ?>