<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Elenco libri</title>
    @include('bootstrap')
</head>
<body>
    <div class="container">
<h3>Libro cancellato con successo</h3>
    </div>
<a href="/books">Torna alla lista dei libri</a>

</body>
</html>