<div class="text-center text-muted w-full">
    By SaraBenti - {{date ('d/m/Y')}}
</div>